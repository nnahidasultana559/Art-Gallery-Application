

<!DOCTYPE html>
<html>
<head>
	<title>Artist details</title>
	<style>
body{
	background-image: url("artistlist.jpg");
}
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 15px;
}
th {
  text-align: left;
}
table#t01 {
  width: 100%; 
  background-color: LightGray;

}
table#t01 th {
  background-color: MediumSeaGreen;
  color: black;
}

ul h2.active a{
	background-color:MediumSeaGreen;
	color:#00;
}
ul h2 a{
	text-decoration: none;
	color: White;
	padding: 10px 20px;
	border: 1px solid transition;
	transition: 0.4s ease;
}
ul h2 a:hover{
	background-color:green;
	color:#00;
}
</style>
</head>
<body>
<br>
<ul>
<h2 class="active" align="left" style= "color:white;margin-bottom: 5px;"><a href="index2.html">Home page</a></h2></ul>
 <br><h1 align="center">Artist List</h1>
 <br>
<?php 

    include("dbcon.php");

    $query = "SELECT * FROM artist";

    $queryfire = mysqli_query($con,$query);

    $num = mysqli_num_rows($queryfire);
    ?>
<table align="center" style="width:80%" id="t01">
  <tr>
    <th>Artist Name</th>
    <th>Birth Place</th> 
    <th>Art Works</th>
    <th>Link</th>
</tr>
  <?php
if($num > 0){
        while($result = mysqli_fetch_array($queryfire)){
        ?>

    <tr>
    <td><?php echo $result['Artist_name'];?></td>
    <td><?php echo $result['birth_place'];?></td> 
    <td><?php echo $result['art_work'];?></td>
    
     <td><a href="artist1.php?id=<?=$result['artist_id']?>" class="text-danger lead" ><h5><input type="submit" name="link" value='link' style="font-size:15px"></h5></a></td> 

    
    <?php
    }
  }

    ?>
    
  </tr>
</table>
</body>
</html>

