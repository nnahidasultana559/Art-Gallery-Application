<?php
  session_start();
   require "dbcon.php";

  if(isset($_POST['pcode'])){
  	$pcode = $_POST['pcode'];
  	$pname = $_POST['pname'];
  	$pprice = $_POST['pprice'];
  	$pimage = $_POST['pimage'];

    $pqty =1;

    $stmt =$con->prepare("SELECT code FROM cart WHERE code=?");
    $stmt->bind_param("i",$pcode);
    $stmt->execute();
    $res = $stmt->get_result();
    $r= $res->fetch_assoc();
    $code =$r['code'];

    if(!$code){
       $query = $con->prepare("INSERT INTO cart (product_name,product_price,product_quantity,product_img,total_price,code) VALUES (?,?,?,?,?,?)");
       $query->bind_param("siisii",$pname,$pprice,$pqty,$pimage,$pprice,$pcode);
       $query->execute();
       echo '<div class="alert alert-success alert-dismissible mt-2">
  <button type="button" class="close" data-dismiss="alert">&times;</button>
  <strong>Iteam added to your cart!</strong>
</div>';

    }
    else{

    	   echo '<div class="alert alert-danger alert-dismissible mt-2">
  <button type="button" class="close" data-dismiss="alert">&times;</button>
  <strong>Iteam  already added to your cart!</strong>
</div>';

    }



  }
  if(isset($_GET['cartIteam'])&& isset($_GET['cartIteam']) == 'cart_item'){
  	$stmt =$con->prepare("SELECT * FROM cart");
  	$stmt->execute();
  	$stmt->store_result();
  	$rows=$stmt->num_rows;
  	echo $rows;
  }

  if(isset($_GET['remove'])){
  	$code= $_GET['remove'];
  	$stmt = $con->prepare("DELETE FROM cart WHERE code=?");
  	$stmt->bind_param("i",$code);
    $stmt->execute();

  	$_SESSION['showAlert']='block';
  	$_SESSION['message']="Iteam  removed from the cart!";

  	header('location:cartnext.php');

  }

  if(isset($_GET['clear'])){
  	$stmt= $con->prepare("DELETE FROM cart");
  	$stmt->execute();
  	$_SESSION['showAlert']='block';
  	$_SESSION['message']="All Iteam removed from the cart!";

  	header('location:cartnext.php');

  } 

  if(isset($_POST['qty'])){
  	$qty=$_POST['qty'];
  	$pcode= $_POST['pcode'];
  	$pprice=$_POST['pprice'];
  	$tprice= $qty*$pprice;
     echo $qty;
  	$stmt= $con->prepare("UPDATE cart SET product_quantity=?, total_price=? WHERE code=?");
  	$stmt->bind_param('iii',$qty,$tprice,$pcode);
  	$stmt->execute();


  }
   if(isset($_POST['action']) && isset($_POST['action'])=='order'){
   	 $name= $_POST['name'];
   	 $email= $_POST['email'];
   	 $phone =$_POST['phone'];
   	 $products= $_POST['products'];
   	
   	 $grand_total =$_POST['grand_total'];
   	 $address= $_POST['address'];
     $pmode = $_POST['pmode'];
    
      $data ='';
     $stmt =$con->prepare("INSERT INTO checkout (name,email,phone,address,pmode,products,amount_paid) VALUES (?,?,?,?,?,?,?)");
     $stmt->bind_param("ssisssi",$name,$email,$phone,$address,$pmode,$products,$grand_total);
      $stmt->execute();
      $data .='<div class="text-center"
                <h1 class="display-4 mt-2 text-danger">Thank You!</h1>
                <h2 class="text-success">Your Order Placed Successfully!</h2>
                <h4 class="bg-danger text-light rounded p-2">Items Purchased: '.$products.'</h4>
                <h4>Your Name:'.$name.'</h4>
                <h4>Your E-mail:'.$email.'</h4>
                <h4>Your Phone:'.$phone.'</h4>
                <h4>Total Amount Paid: $'.number_format($grand_total,2).'</h4>
                <h4>Payment Mode:'.$pmode.'</h4>
                </div>';
       echo $data;
   }

?>