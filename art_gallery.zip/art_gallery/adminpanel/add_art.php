<?php
include("dbcon.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	 <link rel="stylesheet" type="text/css" href="css1/edit_art.css">
</head>
<body>
<form action="add_art.php" method="GET">
<table>
<tr>
<td>Name:</td>
<td><input type="text" name="name" value="" class="textInput" ></td></tr>
<tr>
<td>Image:</td>
<td><input type="text" name="image" value="" class="textInput"></td></tr>
<tr>
<td>Subject:</td>
<td><input type="text" name="subject" value="" class="textInput"></td></tr>
<tr>
<td>Style:</td><td><input type="text" name="style" value="" class="textInput"></td></tr>
<tr>
<td>Medium:</td><td><input type="text" name="medium" value="" class="textInput"></td></tr>
<tr>
<td>Size:</td><td><input type="text" name="size" value="" class="textInput"></td></tr>
<tr>
<td>Price:</td><td><input type="text" name="price" value="" class="textInput"></td></tr>
<tr>
<td>Artist Name:</td><td><input type="text" name="ar_name" value="" class="textInput"></td></tr>
<tr>
<td>Artist Country:</td><td><input type="text" name="ar_country" value="" class="textInput"></td></tr>
<tr>

	<td>
<h4 style="margin-left:20px"><input type="submit" name="Add" value="Update"></h4></td></tr>

<br>
<?php 
   if(isset($_GET['Add'])){
   	$name= $_GET['name'];
   	 $image= $_GET['image'];
   	  $subject= $_GET['subject'];
   	   $style= $_GET['style'];
   	    $medium= $_GET['medium'];
   	     $size= $_GET['size'];
   	     $price= $_GET['price'];
   	      $ar_name= $_GET['ar_name'];
   	      $ar_country = $_GET['ar_country'];
         

   if($name!='' && $subject!='' && $style!='' && $medium!='' && $size!='' && $price!='' && $ar_name!='' && $ar_country!='' && $image!=''){

  $query="INSERT INTO `art_in_sale` (`Name`, `subject`, `style`, `medium`, `artist_name`, `artist_country`, `size`, `price`, `images`,`gallery_id`) VALUES ('$name','$subject','$style','$medium','$ar_name','$ar_country','$size','$price','$image','1')";

   	 $data = mysqli_query($con,$query);

if($data){
	?>
	<tr><td>
	<?php echo "Record updated successfully.&nbsp;&nbsp;<a href='art_sale_update.php'>Check Added List Here</a>"; ?></td></tr>
    <?php
}
else{
   ?>
   <tr><td>
	 <?php echo "Not updated";?></td></tr>
<?php
}
}
}
   else{
   ?>
   <tr><td>
   	<?php echo "<font color='blue'>Click on Add Button to add new data!";?></td></tr>
   	<?php	
   }

?>
</table>
</form>
</body>
</html>