<?php 
   session_start();
include ("dbcon.php");
if (isset($_POST['register'])) {
  
$Username= $_POST['username'];
$email= $_POST['email'];
$password=$_POST['password'];
$password2=$_POST['password2'];

 if($password==$password2){
   $password=md5($password);
   $sql= "INSERT INTO admin (`name`, `password`, `email`,`gallery_id`) VALUES ('$Username','$password','$email','1')";
   mysqli_query($con,$sql);
   $_SESSION['message']="You are now logged in";
   $_SESSION['username']= $Username;
   header('location:adminhome.php');
 }
 else if($password!=$password2){
  
    $_SESSION['message']="The two passwords do not match"; 
   
 }
}

?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration</title>
 <link rel="stylesheet" type="text/css" href="css1/adminuser.css">
</head>
<body>
<div class= "header">
  <h1>Registration</h1>
  
</div>
<?php 
  if(isset($_SESSION['message'])){
      echo "<div id='message'>".$_SESSION['message']."</div>";
      unset($_SESSION['message']);
  }

?>
<form method="post" action="admin1.php">
  <table>
    <tr>
      <td>Username:</td>
      <td><input type="text" name="username" class="textInput"></td>
    </tr>
     <tr>
      <td>Email:</td>
      <td><input type="email" name="email" class="textInput"></td>
    </tr>
     <tr>
      <td>Password:</td>
      <td><input type="password" name="password" class="textInput"></td>
    </tr>
     <tr>
      <td>Confirm Password:</td>
      <td><input type="password" name="password2" class="textInput"></td>
    </tr>

      <tr>
      <td></td>
      <td><br><input type="submit" name="register" value="Register"></td>
    </tr>
    <tr>
     <td>
    <h4>Already have account?&nbsp&nbsp<a href="login.php">login</a></h4>
      
      </td></tr>
  </table>
</form>
</body>
</html>