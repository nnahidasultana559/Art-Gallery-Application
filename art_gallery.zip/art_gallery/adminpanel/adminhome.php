<?php 
  session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Home</title>
  
 <link rel="stylesheet" type="text/css" href="css1/adminuser.css">
</head>
<body>
<div class= "header">
<h1 >Admin Page</h1>
</div>
<?php 
  if(isset($_SESSION['message'])){
      echo "<div id='message'>".$_SESSION['message']."</div>";
      unset($_SESSION['message']);
  }

?>

<div><h2 style='text-align: center'>Welcome <?php echo $_SESSION['username']; ?></h2></div>
<div><h2><a style="margin-left:30px; " href='art_sale_update.php'>Arts</a></h2></div>
<div><h2><a style="margin-left:30px; "href='artist_update.php'>Artist</a></h2></div>
 
<div><h2><a style="margin-left:30px;" href='logout.php'>Logout</a></h2></div>

</body>
</html>