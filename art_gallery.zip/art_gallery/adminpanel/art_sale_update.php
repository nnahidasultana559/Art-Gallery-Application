 <!DOCTYPE html>
<html>
<head>
  
 <meta charset="utf-8">
  <meta http-equiv="X-US-Compatible" content="IE-edge">
  <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
  <title>Arts</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
   <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

     
</head>
<body>
  <h4 class="active" align="left" style= "color:white;margin-bottom: 5px;margin-left: 30px"><a href="adminhome.php">Admin page</a></h4>
<h3 align="center">Art_In_Sale</h3>
 <div class="row justify-content:space-around">
    <div style="display:flex">
  <div class="col-sm-12">
    <div class="table-responsive mt-2">
  
    <table class="table table-bordered table-striped text-center">
     <thead>    
  <tr>
   <th>Name</th>
   <th>Image</th>
   <th>Subject</th>
   <th>Size</th>
   <th>Medium</th>
   <th>Style</th>
   <th>Price</th>
   
   <th>Artist Name</th>
   <th>Artist Country</th>
   
   <th> code</th>
   <th>Remove</th>
   <th>Update</th>
  <?php
   include ('dbcon.php');
   $query="SELECT *FROM `art_in_sale`";
   $result=mysqli_query($con,$query);
    while ($row= $result->fetch_assoc()) {
    ?>
    <tr>
   <td><?=$row['Name']?></td>
    <td><img src="<?= $row['images']?>" width='50'></td>

     <td><?=$row['subject']?>
     <td><?=$row['size']?></td>
      <td><?=$row['medium']?></td>
     <td><?=$row['style']?> </td>
     <td><?=$row['price']?></td>
    
     <td><?=$row['artist_name']?></td>
     <td><?=$row['artist_country']?></td>
     
     <td><?=$row['code']?></td>
      <td><a href="remove.php?remove=<?=$row['code']?>" class="text-danger lead" onclick="return confirm('Are you sure want to remove this iteam?')";><h5><input type="submit" name="remove" value='Remove' style="font-size:15px"></h5></a></td> 

       <td><a href="edit_art.php?cd=<?=$row['code']?>&nm=<?=$row['Name']?>&img=<?= $row['images']?>&sb=<?=$row['subject']?>&st=<?=$row['style']?>&md=<?=$row['medium']?>&sz=<?=$row['size']?>&pr=<?=$row['price']?>&an=<?=$row['artist_name']?>&ac=<?=$row['artist_country']?>" class="text-danger lead"><h5><input type="submit" name="update" value='Update' style="font-size:15px"></h5></a></td>
       

 <?php
    }

  ?>
  </div>
</tr>
</thead>
</table>
 <td><a href="add_art.php" class="text-danger lead"  ><h5><input type="submit" name="add" value='Add New' style="font-size:15px;"></h5></a></td>
</div>
</div>
</div>