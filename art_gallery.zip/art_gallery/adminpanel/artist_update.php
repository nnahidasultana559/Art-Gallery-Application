 <!DOCTYPE html>
<html>
<head>
  
 <meta charset="utf-8">
  <meta http-equiv="X-US-Compatible" content="IE-edge">
  <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
  <title>Arts</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
   <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

     
</head>
<body>
  <h4 class="active" align="left" style= "color:white;margin-bottom: 5px;margin-left: 30px"><a href="adminhome.php">Admin page</a></h4>
<h3 align="center">Artist Details</h3>
 <div class="row justify-content:space-around">
    <div style="display:flex">
  <div class="col-lg-12">
    <div class="table-responsive mt-2">
  
    <table class="table table-bordered table-striped text-center">
     <thead>    
  <tr>
   <th>Artist Name</th>
   <th>artist_image</th>
   <th>Birth Place</th>
   <th>Art Work</th>
    <th> age</th>
   
   <th>Type_of_art</th>
   
   <th>publication</th>
   <th> Artist ID</th>
   <th>Remove</th>
   <th>Update</th>
  <?php
   include ('dbcon.php');
   $query="SELECT *FROM `artist`";
   $result=mysqli_query($con,$query);
    while ($row= $result->fetch_assoc()) {
    ?>
    <tr>
   <td><?=$row['Artist_name']?></td>
    <td><img src="<?= $row['artist_image']?>" width='50'></td>

     <td><?=$row['birth_place']?>
     <td><?=$row['art_work']?></td>
     <td><?=$row['age']?> </td>
    
      <td><?=$row['type_of_art']?></td>
     
     
     <td><?=$row['publication']?></td>
     
     <td><?=$row['artist_id']?></td>
      <td><a href="remove_artist.php?remove=<?=$row['artist_id']?>" class="text-danger lead" onclick="return confirm('Are you sure want to remove this iteam?')";><h5><input type="submit" name="remove" value='Remove' style="font-size:15px"></h5></a></td> 

       <td><a href="edit_artist.php?id=<?=$row['artist_id']?>&nm=<?=$row['Artist_name']?>&img=<?= $row['artist_image']?>&bp=<?=$row['birth_place']?>&aw=<?=$row['art_work']?>&ta=<?=$row['type_of_art']?>&ag=<?=$row['age']?>&pb=<?=$row['publication']?>" class="text-danger lead"><h5><input type="submit" name="update" value='Update' style="font-size:15px"></h5></a></td>


       

 <?php
    }

  ?>
  </div>
</tr>
</thead>
</table>
 <td><a href="add_artist.php" class="text-danger lead"  ><h5><input type="submit" name="add" value='Add New' style="font-size:15px;margin-left: 40px;"></h5></a></td>
</div>
</div>
</div>