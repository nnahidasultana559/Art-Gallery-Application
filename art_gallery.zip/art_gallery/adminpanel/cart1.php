<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-US-Compatible" content="IE-edge">
	<meta name="viewpor" content="width=device-width,initial-scale=1,shrink-to-fit=no">
	<title>Art Gallery</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
     
</head>
<body>
	<nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <!-- Brand -->
  <a class="navbar-brand" href="cart1.php"> Art Gallery</a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav ml-auto">
     <li class="nav-item">
        <a class="nav-link" href="index2.html">Home Page</a>
      </li>
      
     
      </li> 
    </ul>
  </div> 
</nav>
<div class="container">
<div id='message'></div>
<div class="row mt-3 pb-1">
	<?php
    include ('dbcon.php');
    $stmt= $con->prepare ("SELECT *FROM art_in_sale");
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row= $result->fetch_assoc()) {
    ?>

    <div class="col-sm-6 col-md-4 col-lg-4 mb-2">

    <div class="card-deck">
    
    	<div class="card p-1 border-secondary mb-3">
    		<img src="<?= $row["images"]?>" class="card-top"
    		height="275" >
    		
    		<div class="card-body p-1">
    	  <h4 class="card-title text-center text-info"><?= $row['Name']?></h4>
    	  <h5 class="cart-text text-center text-danger"><i class="fa fa-usd"></i>&nbsp<?= number_format($row['price'],2)?></h5>

    	  <h6 class="card-title text-center text-info">Subject:&nbsp<?= $row['subject']?></h6>
    	  <h6 class="card-title text-center text-info">Size:&nbsp<?= $row['size']?></h6>
    	  <h6 class="card-title text-center text-info">Style:&nbsp<?= $row['style']?></h6>
    	  
    	  <h6 class="card-title text-center text-info">Medium:&nbsp<?= $row['medium']?></h6>
          
          <h6 class="card-title text-center text-info">Artist Name:&nbsp<?= $row['artist_name']?></h6>
          <h6 class="card-title text-center text-info">Artist Country:&nbsp<?= $row['artist_country']?></h6>

         </div>
         <div class="cart-footer p-1">
         <form action ="" class="form-submit">
         <input type="hidden" class='pcode' value="<?= $row['code']?>">
         <input type="hidden" class='pname' value="<?= $row['Name']?>">
         <input type="hidden" class='pprice' value="<?= $row['price']?>">
         <input type="hidden" class='pimage' value="<?= $row['images']?>">
        
     </form>
         
         	
         </div>
    	</div>

    </div>
    </div>	
 <?php
    }

	?>

</div>

</div>
 
</body>
</html>