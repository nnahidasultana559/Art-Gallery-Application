<?php
include("dbcon.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	 <link rel="stylesheet" type="text/css" href="css1/edit_art.css">
</head>
<body>
<form action="add_artist.php" method="GET">
<table>
<tr>
<td>First Name:</td>
<td><input type="text" name="F_name" value="" class="textInput" ></td></tr>
<tr>
   <tr>
<td>Last Name:</td>
<td><input type="text" name="birth" value="" class="textInput"></td></tr>
<td>Image:</td>
<td><input type="text" name="image" value="" class="textInput"></td></tr>
<tr>
<td>Phone:</td><td><input type="text" name="age" value="" class="textInput"></td></tr>
<tr>
<td>Address:</td><td><input type="text" name="about" value="" class="textInput"></td></tr>
	<td>
<h4 style="margin-left:20px"><input type="submit" name="Add" value="Update"></h4></td></tr>

<br>
<?php 
   if(isset($_GET['Add'])){
   	$name= $_GET['artist_name'];
   	 $image= $_GET['image'];
   	  $birth= $_GET['birth'];
   	   $age= $_GET['age'];
   	    $about= $_GET['about'];
   	     $publication= $_GET['publication'];
   	     $education= $_GET['education'];
   	      $art_work= $_GET['art_work'];
   	      $type= $_GET['type'];
         



  $query="INSERT INTO `artist`(`Artist_name`, `birth_place`, `art_work`, `type_of_art`, `age`, `about`, `education`, `artist_image`, `publication`,`gallery_id`) VALUES ('$name','$birth','$art_work','$type','$age','$about','$education','$image','$publication','1')";

   	 $data = mysqli_query($con,$query);

if($data){
	?>
	<tr><td>
	<?php echo "Record updated successfully.&nbsp;&nbsp;<a href='artist_update.php'>Check Added List Here</a>"; ?></td></tr>
    <?php
}
else{
   ?>
   <tr><td>
	 <?php echo "Not updated";?></td></tr>
<?php
}
}
   else{
   ?>
   <tr><td>
   	<?php echo "<font color='blue'>Click on Add Button to add new data!";?></td></tr>
   	<?php	
   }

?>
</table>
</form>
</body>
</html>