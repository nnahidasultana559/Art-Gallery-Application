
?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
          <style>
body{
  background-image: url("images/background6.jpg");
}
</style>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1 shrink-to-fit=no">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link href="https://fonts.googleapis.com/css?family=Abril+Fatface|Dancing+Script" rel="stylesheet">   
</head>
<style>
  button {

margin-left :10px }
</style>
<body class = "container ">
     <br><div class="btn-sm " >
     <a class="btn btn-info flex-fill" href="index2.html" role="button"> ← Home Page<a class="btn btn-info flex-fill" href="Artist.php" role='button'> ← Previous Page 
     </a>
     </div>
     <br><br>
     <div class='row'>
     
    <?php 

    include("dbcon.php");

    $query = "SELECT * FROM artist where artist_id='14'";

    $queryfire = mysqli_query($con,$query);

    $num = mysqli_num_rows($queryfire);
    ?>

    <?php
    
    if($num > 0){
        while($result = mysqli_fetch_array($queryfire)){
            ?>
   
             <img src="<?php echo $result['artist_image'];?>">
                      <a style="color:white;"><br><br>&nbsp &nbsp &nbsp Artist Name:&nbsp <?php echo $result['Artist_name'];?>
                                                <br>&nbsp &nbsp &nbsp Birth Place:&nbsp<?php echo $result['birth_place']; ?>
                                                 
                                                <br>&nbsp &nbsp &nbsp Art Work:&nbsp <?php echo $result['art_work'];?>
                                                <br>&nbsp &nbsp &nbsp Type of ARTS:&nbsp<?php echo $result['type_of_art'];?>
                                                <br>&nbsp &nbsp &nbsp Age:&nbsp<?php echo $result['age'];?> 

                                            </a>
                       <a style="color:white"><br><br><h4>About Andy Shaw:</h4><br> <?php echo $result['about'];?></a>
                       
                       <a style="color:white"><br><br><h5>Education:</h5><br> <?php echo $result['education'];?>
                      

 
                <br>

        </div>
        <?php
      }
       }

       ?>  
       <br>
                <br>
                </div>
                </div>

           </body>
           </html>  
           