<?php
include("dbcon.php");
error_reporting(0);
 $_GET['cd'];
 $_GET['nm'];
 $_GET['img'];
 $_GET['sb'];
 $_GET['st'];
 $_GET['pr'];
 $_GET['md'];
 $_GET['sz'];
 $_GET['an'];
 $_GET['ac'];

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	 <link rel="stylesheet" type="text/css" href="css1/edit_art.css">
</head>
<body>
<form action="edit_art.php" method="GET"  >
<table>
<tr>
<td>Name:</td>
<td><input type="text" name="name" value="<?php echo $_GET['nm'];?>" class="textInput" ></td></tr>
<tr>
<td>Image:</td>
<td><input type="text" name="image" value="<?php echo $_GET['img'];?>" class="textInput"></td></tr>
<tr>
<td>Subject:</td>
<td><input type="text" name="subject" value="<?php echo $_GET['sb'];?>" class="textInput"></td></tr>
<tr>
<td>Style:</td><td><input type="text" name="style" value="<?php echo $_GET['st'];?>" class="textInput"></td></tr>
<tr>
<td>Medium:</td><td><input type="text" name="medium" value="<?php echo $_GET['md'];?>" class="textInput"></td></tr>
<tr>
<td>Size:</td><td><input type="text" name="size" value="<?php echo $_GET['sz'];?>" class="textInput"></td></tr>
<tr>
<td>Price:</td><td><input type="text" name="price" value="<?php echo $_GET['pr'];?>" class="textInput"></td></tr>
<tr>
<td>Artist Name:</td><td><input type="text" name="ar_name" value="<?php echo $_GET['an'];?>" class="textInput"></td></tr>
<tr>
<td>Artist Country:</td><td><input type="text" name="ar_country" value="<?php echo $_GET['ac'];?>" class="textInput"></td></tr>
<tr>
	<td>
<input type="hidden" name="code" value="<?php echo $_GET['cd'];?>"><br><br>
<h4 style="margin-left:20px"><input type="submit" name="submit" value="Update"></h4></td></tr>

<br>
<?php 
   if(isset($_GET['submit'])){
   	$name= $_GET['name'];
   	 $image= $_GET['image'];
   	  $subject= $_GET['subject'];
   	   $style= $_GET['style'];
   	    $medium= $_GET['medium'];
   	     $size= $_GET['size'];
   	     $price= $_GET['price'];
   	      $ar_name= $_GET['ar_name'];
   	      $ar_country = $_GET['ar_country'];
   	      $code=$_GET['code'];
   	        
   	 $query="UPDATE `art_in_sale` SET `Name`='$name',`subject`='$subject',`style`='$style',`medium`='$medium',`artist_name`='$ar_name',`artist_country`='$ar_country',`size`='$size',`price`='$price',`images`='$image' WHERE `code`='$code'";
   	 $data = mysqli_query($con,$query);

if($data){
	?>
	<tr><td>
	<?php echo "Record updated successfully.&nbsp;&nbsp;<a href='art_sale_update.php'>Check Updated List Here</a>"; ?></td></tr>
    <?php
}
else{
   ?>
   <tr><td>
	 <?php echo "Not updated";?></td></tr>
<?php
}
}
   else{
   ?>
   <tr><td>
   	<?php echo "<font color='blue'>Click on Update Button to save the changes!";?></td></tr>
   	<?php	
   }

?>
</table>
</form>
</body>
</html>