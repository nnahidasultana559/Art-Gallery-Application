<?php
include("dbcon.php");
error_reporting(0);
  $_GET['id'];
  $_GET['nm'];
  $_GET['img'];
  $_GET['bp'];
  $_GET['aw'];

  $_GET['ag'];
  $_GET['pb'];

  $_GET['ta'];

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	 <link rel="stylesheet" type="text/css" href="css1/edit_art.css">
</head>
<body>
<form action="edit_artist.php" method="GET"  >
<table>
<tr>
<td>Artist Name:</td>
<td><input type="text" name="name" value="<?php echo $_GET['nm'];?>" class="textInput" ></td></tr>
<tr>
<td>Image:</td>
<td><input type="text" name="image" value="<?php echo $_GET['img'];?>" class="textInput"></td></tr>
<tr>
<td>Birth Place:</td>
<td><input type="text" name="birth" value="<?php echo $_GET['bp'];?>" class="textInput"></td></tr>
<tr>
<td>Art Work:</td><td><input type="text" name="artwork" value="<?php echo $_GET['aw'];?>" class="textInput"></td></tr>
<tr>
<td>Type of Work:</td><td><input type="text" name="type" value="<?php echo $_GET['ta'];?>" class="textInput"></td></tr>
<tr>

<tr>
<td>Publication:</td><td><input type="text" name="pub" value="<?php echo $_GET['pb'];?>" class="textInput"></td></tr>
<tr>

<tr>
<td>Age:</td><td><input type="text" name="age" value="<?php echo $_GET['ag'];?>" class="textInput"></td></tr>
<tr>
	<td>
<input type="hidden" name="id" value="<?php echo $_GET['id'];?>"><br><br>
<h4 style="margin-left:20px"><input type="submit" name="submit" value="Update"></h4></td></tr>

<br>
<?php 
   if(isset($_GET['submit'])){
   	$name= $_GET['name'];
   	 $image= $_GET['image'];
   	  $birth= $_GET['birth'];
   	   $artwork= $_GET['artwork'];
   	    $type= $_GET['type'];
   	     $about= $_GET['about'];
   	     $pub= $_GET['pub'];
   	      $edu= $_GET['edu'];
   	      $age = $_GET['age'];
   	      $id=$_GET['id'];
   	        
    $query="UPDATE `artist` SET `Artist_name`='$name',`birth_place`='$birth',`art_work`='$artwork',`type_of_art`='$type',`age`='$age',`artist_image`='$image',`publication`='$pub' WHERE `artist_id`='$id'";
   	 $data = mysqli_query($con,$query);

if($data){
	?>
	<tr><td>
	<?php echo "Record updated successfully.&nbsp;&nbsp;<a href='artist_update.php'>Check Updated List Here</a>"; ?></td></tr>
    <?php
}
else{
   ?>
   <tr><td>
	 <?php echo "Not updated";?></td></tr>
<?php
}
}
   else{
   ?>
   <tr><td>
   	<?php echo "<font color='blue'>Click on Update Button to save the changes!";?></td></tr>
   	<?php	
   }

?>
</table>
</form>
</body>
</html>