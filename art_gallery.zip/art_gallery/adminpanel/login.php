<?php 
  session_start();
include ("dbcon.php");

if (isset($_POST['login'])) {
  
$username= $_POST['username'];
$password= $_POST['password'];

   $password=md5($password);
   $sql= "SELECT * FROM admin WHERE name ='$username' AND password ='$password'";

   $result=mysqli_query($con,$sql);

   if(mysqli_num_rows($result)==1){
   $_SESSION['message']="You are now logged in";
   $_SESSION['username']= $username;
   header('location:adminhome.php');
 }
 else{
   $_SESSION['message']="Username or password not match";
 }

}

?>
<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <link rel="stylesheet" type="text/css" href="css1/adminuser.css">
</head>
<body>
<div class= "header">
  
    <h3 class="active" align="left" style="margin-left: 20px;"><a href="index2.html">Home Page</a></h3>
  <h1>Login</h1>

  
</div>
<?php 
  if(isset($_SESSION['message'])){
      echo "<div id='message'>".$_SESSION['message']."</div>";
      unset($_SESSION['message']);
  }

?>
<form method="post" action="login.php">
  <table>
    <tr>
      <td>Username:</td>
      <td><input type="text" name="username" class="textInput"></td>
    </tr>
     
     <tr>
      <td>Password:</td>
      <td><input type="password" name="password" class="textInput"></td>
    </tr>
      <tr>
      <td></td>
      <td><br><input type="submit" name="login" value="login"></td>
    </tr>
    <tr>
      <td><h4>Not Yet Registered?
     <br>Register Here&nbsp&nbsp<a href="admin1.php">Register</a></h4>

      </td></tr>
  </table>
</form>
</body>
</html>