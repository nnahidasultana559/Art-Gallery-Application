<!DOCTYPE html>
<html>
<head>
	<title>Remove data</title>
</head>
<body>
	<?php
    
include('dbcon.php');


 if(isset($_GET['remove'])){
  	$code= $_GET['remove'];
  	$stmt = $con->prepare("DELETE FROM art_in_sale WHERE code=?");
  	$stmt->bind_param("i",$code);
    $stmt->execute();

  	$_SESSION['showAlert']='block';
  	$_SESSION['message']="Iteam  removed from the cart!";

  	header('location:art_sale_update.php');

  }


?>
</body>
</html>