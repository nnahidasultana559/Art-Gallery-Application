<!DOCTYPE html>
<html>
<head>
	<title>Remove data</title>
</head>
<body>
	<?php
    
include('dbcon.php');


 if(isset($_GET['remove'])){
  	$id= $_GET['remove'];
  	$stmt = $con->prepare("DELETE FROM artist WHERE artist_id=?");
  	$stmt->bind_param("i",$id);
    $stmt->execute();

  	$_SESSION['showAlert']='block';
  	$_SESSION['message']="Iteam  removed from the cart!";

  	header('location:artist_update.php');

  }


?>
</body>
</html>