<!DOCTYPE html>
<html>
<head>
<title>User login</title>
<link rel ="stylesheet" type="text/css" href="css/userstyle.css">
<br>
</head>
<body>
     <header>
     	<div class="main">
	<ul>
	<h1 align="center">User Login:</h1><br><br><br>
     <form action="Users.php" method="post">
<table align="center">
   <tr>
      <td>Username: </td><td><input type="text" name="uname" required></td>
</tr>
<tr>
<td>Password: </td><td><input type="password" name="pass" required></td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="login" value="Login">
</td>
</tr>
</table>
</form>
</div>
</header>
</body>
</html>

<?php
include("dbcon.php");
if(isset($_POST['login']))
{
	$username=$_POST['uname'];
	$password=$_POST['pass'];

	$qry= "SELECT * FROM `users` WHERE `username`='$username' and `password`='$password'";
	$run=mysqli_query($con,$qry);
    $row=mysqli_num_rows($run);

    if($row<1){
       ?>
       <script>
    	alert ('username or password not match!! ');
    	window.open('Users.php','_self');
    	</script>
    	<?php
    }
    else {
    	$data=mysqli_fetch_assoc($run); 
    	$id=$data['ID'];

    	session_start();

    	$_SESSION['ID']=$id;
    	header('location:customer.php' ); 
    }
}

?>