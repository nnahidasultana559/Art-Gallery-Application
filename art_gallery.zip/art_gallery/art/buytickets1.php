<?php

include ("dbcon.php");

?>
<!DOCTYPE html>
<html>
<head>
  <title></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

     
       
</head>
<style>
  .row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

.container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 98%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  background-color: #4CAF50;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}

span.price {
  float: right;
  color: grey;
}

@media (max-width: 700px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 40px;
  }
}
ul h2.active a{
  background-color:MediumSeaGreen;
  color:#00;
}
ul h2 a{
  text-decoration: none;
  color: white;
  padding: 10px 20px ;
  border: 1px solid transition;
  transition: 0.4s ease;
}
ul h2 a:hover{
  background-color:green;
  color:#00;
}
</style>
<body>

<div class="row">
  <div class="col-75">
    <div class="container">
      <form action="buytickets1.php" method="GET">
       <ul>
     <h2 class="active" align="left" style= "color:white;margin-bottom:5px;"><a href="index2.html">Home page</a><a href="exhibitionlist.php">Previous Page</a></h2></ul>
        <div class="row">
          <div class="col-50">
            <h3>Billing Ticket </h3>
            <label for="fname"><i class="fa fa-user"></i> Full Name</label>
            <input type="text" id="name" name="name" placeholder="your name">
            <label for="email"><i class="fa fa-envelope"></i> Email</label>
            <input type="text" id="email" name="email" placeholder="XXX@example.com">
            <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
            <input type="text" id="adr" name="address" placeholder="your home address">
            <label for="qty"><i class="quantity"></i> Quantity</label>
            <input type="text/number" id="qty" name="qty" placeholder="Ticket quantity less than 11" style="width:98%;height:10%">

          </div>

          <div class="col-50">
            <br><h3>Payment</h3>
            <label for="fname">Accepted Cards</label>
            <div class="icon-container">
              <i class="fa fa-cc-visa" style="color:navy;"></i>
              <i class="fa fa-cc-paypal" style="color:red;"></i>
              <i class="fa fa-cc-amex" style="color:blue;"></i>

              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
            <label for="cname">Name on Card</label>
            <input type="text" id="cardname" name="cardname" placeholder="XXX XXX XXX">
            <label for="ccnum">Credit card number</label>
            <input type="text" id="cardnumber" name="cardnumber" placeholder="1111-2222-3333-4444">
            <label for="expmonth">Exp Month</label>
            <input type="text" id="expmonth" name="expmonth" placeholder="September">

            <div class="row">
              <div class="col-50">
                <label for="expyear">Exp Year</label>
                <input type="text" id="expyear" name="expyear" placeholder="2018">
              </div>
              <div class="col-50">
                <label for="cvv">CVV</label>
                <input type="text" id="cvv" name="cvv" placeholder="352">
              </div>
            </div>
          </div>

        </div>
        <label>
          <input type="checkbox" checked="checked" name="sameadr"> Shipping address same as billing
        </label>
        <input type="submit" name="submit" value="checkout" class="btn">

         <div class="col-25">
    <div class="container">
      <h4>Cart 
        <span class="price" name='price' style="color:black">
          <i class="fa fa-shopping-cart"></i> 
        </span>
      </h4>
        
         </div>
  </div>
      </form>
         <?php 
        
        $stmt="SELECT * FROM exhibition";
        $res=mysqli_query($con,$stmt);
        if($rest = mysqli_fetch_array($res)){
        
        ?>
      <p><a>Ticket price</a> <span class="price"><?php echo $rest['ticket_price'];?></span></p>
       
      <?php
         
      if(isset($_GET['submit'])){
        $name=$_GET['name'];
        $address=$_GET['address'];
        $cardname=$_GET['cardname'];
        $cardnumber=$_GET['cardnumber'];
        $email=$_GET['email'];
        $expmonth=$_GET['expmonth'];
        $expyear=$_GET['expyear'];
        $cvv=$_GET['cvv'];
        $quantity=$_GET['qty'];
        $total_price=0; $price=$rest['ticket_price']; 
            
      for($i=1;$i<=$quantity;$i++){ 

        $total_price=$price *$i ; }?>

      <hr>
      <a><span class="price" style="color:black;margin-right:30px" ><b>Total&nbsp&nbsp&nbsp<?php echo '$'.$total_price?> </b></span></a><br>
       
      <?php

      $con=mysqli_connect('localhost','root','','art_gallery');

  if($name!='' && $address!='' && $cardname!='' && $cardnumber!='' &&  $expyear!=''  && $expmonth!='' && $email!='' && $cvv!='' && $quantity!='' && $total_price!=''){
     
      $query = ("INSERT INTO `buytickets`(name,address,email,cardname,cardnumber,expmonth,expyear,cvv,price,quantity) VALUES ('$name','$address','$email','$cardname','$cardnumber','$expmonth','$expyear','$cvv','$total_price','$quantity')");
  
      $data=mysqli_query($con,$query);


      if($data){
        echo "Ticket Purchased Successfully";
      }
      else{
        echo "not sent";
      }   
}
  else{
     ?><a style="margin-left:20px;"></a> <?php echo "All field are required";  
  }
}

     ?>  
     <?php } ?>
    </div>
  </div>

 </div>

</body>
</html>