<?php
include ("dbcon.php");

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
ul h2.active a{
  background-color:MediumSeaGreen;
  color:#00;
}
ul h2 a{
  text-decoration: none;
  color: white;
  padding: 10px 20px;
  border: 1px solid transition;
  transition: 0.4s ease;
}
ul h2 a:hover{
  background-color:green;
  color:#00;
}
</style>
</head>
<body>
<ul>
<h2 class="active" align="left" style= "color:white;margin-bottom: : 5px;"><a href="index2.html">Home page</a></h2></ul>
<br><h3 style="margin-left: 20px">Contact Form</h3>

<div class="container">
  <form action="contact.php"  method="GET">
    <label for="fname">First Name</label>

    <input type="text"  name="First_name" value='' placeholder="Your First name..">

    <label for="lname">Last Name</label>
    <input type="text" name="Last_name" value='' placeholder="Your last name..">

    <label for="Email">Email</label><br>
     <input type="Email" name="email" value="" placeholder="Your email address.." style="width:1290px; height:40px"></textarea><br><br>
      
    <label for="message">Message</label>
         <textarea  type='text' name="msg" value="" placeholder="Write something.." style="height:200px"></textarea>


    <input type="submit" name="submit" value="submit">
  </form>
  <?php

   if(isset($_GET['submit'])){
   $First_name=$_GET['First_name'];
   $Last_name=$_GET['Last_name'];
   $email=$_GET['email'];
   $msg=$_GET['msg'];

  if($First_name!='' && $Last_name!='' && $email!='' && $msg!=''){
     
    $query="INSERT INTO `contact_us`(`First_name`,`Last_name`,`email_address`,`msg`,`gallery_id`) VALUES ('$First_name','$Last_name','$email','$msg','1')";
  
      $data=mysqli_query($con,$query);

      if($data){
        echo "Your Message is sent";
      }

      
}
  else{
    echo "All field are required";
  }
}

?>
</div>


</body>
</html>