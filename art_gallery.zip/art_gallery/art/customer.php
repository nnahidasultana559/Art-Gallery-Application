<?php include("signupCon.php");
   if(empty($_SESSION['username'])){
     header(('location: login.php'));
   }

 ?>

<!DOCTYPE html>
<html>
<head>
     <title>User</title>
     <link rel="stylesheet" type="text/css" href="css/userstyle1.css">
</head>
<body>
     <div class="header">
          <h2>User Account</h2>
     </div>
          <div class="content">
          <?php if (isset($_SESSION['success'])): ?>
          <div class="error success">
          <h3>
          <?php 
             echo $_SESSION['success'];
             unset($_SESSION['success']);
             ?>
        </h3>
   </div>
          <?php endif ?>
          <?php if (isset($_SESSION['username'])){ ?>
          <p>WELCOME <strong><?php echo $_SESSION['username']; ?></strong></p>
          <h3>Your details</h3>
           
          <?php 
          require 'dbcon.php';
          ?>
             <?php
          $name=$_SESSION['username'];

       $stmt =$con->prepare("SELECT * FROM `users` WHERE  `username`='$name'");
       $stmt->execute();
       $result =$stmt->get_result();
            
         $query="SELECT * FROM  `customer` ";
          $rest=mysqli_query($con,$query);
        
         if ($res=$rest->fetch_assoc()) {
         ?>
    <tr>
    <h4><img src="<?= $res['image']?>" width='200' align='center'></h4></tr>
    <br><tr><h4>First Name:<?=$res['F_name']?></h4></tr>
   <br><tr><h4>Last Name:<?=$res['L_name']?></h4></tr>
   <br><tr><h4>Phone:<?=$res['phone']?></h4></tr>
   <br><tr><h4>Address:<?=$res['address']?></h4></tr>
      <?php  

       while ($row= $result->fetch_assoc()) {
         ?>
          
          <br><h4>Email:<?php echo $row['email']; ?></h4>
          <br><h4>Discount:<?php echo $row['discount'];?></h4>
         
         
         <?php }
          


          ?>
         
            <?php 

             } 
        
        ?>
           
      
            <div class="input-group">
            <input type="hidden" class='id'  value="<?= $_SESSION['username'] ?>">  
             <button type="text" name="submit"  class="btn "><h3><a href="customer3.php">Add Information</a></h3></button></div>
          <p><a href="customer.php?logout='1'" style="color: red; ">Logout</a></p>

          <?php } ?>
              
          </div>
         
</body>
</html>