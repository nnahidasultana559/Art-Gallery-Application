<?php
include("dbcon.php");

?>

<!DOCTYPE html>
<html>
<head>
	<title>ADD Information</title>
</head>
<body>
    <form method="GET" action="">
     <table>
     	<tr>
     	<td>
     	First Name<input type="text" name="F_name" value="">	
     	</td></tr>
     	<tr>
     	<td>Last Name<input type="text" name="L_name" value=""></td>
         </tr>
         <tr>
         <td>Phone<input type="text" name="phone" value="">	
     	</td></tr>
     	<tr>
     	 <td>Address<input type="text" name="address" value="">	
     	</td></tr>
     	<tr><td>Image<input type="file" name="image"  value=''>
         </td></tr>
         <tr><td><input type="submit" name="submit"  value='submit'>
         </td></tr>
     </table>
    </form>
    <?php
       if(isset($_GET['submit'])){
    	$fname=$_GET['F_name'];
    	$lname=$_GET['L_name'];
    	$phone=$_GET['phone'];
        $address=$_GET['address'];
        $image=$_GET['image'];
         
      if($fname!='' && $lname!='' && $phone!='' && $address='' && $image!=''){
         echo $fname;
         echo $lname;
         echo $phone;
         echo $address;
         echo $image;
       $stmt ="INSERT INTO `customer`(`F_name`, `L_name`, `phone`, `address`,`image`) VALUES ('$fname','$lname','$phone','$address','image')";
       
      $data=mysqli_query($con,$stmt);

      if($data){
        echo "Your Message is sent";
      }
      else{
       echo "not sent";
        }
}
  else{
    echo "All field are required";
  }
}

    ?>
</body>
</html>