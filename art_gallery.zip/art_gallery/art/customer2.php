<?php
include("dbcon.php");

   if(isset($_GET['submit'])){
      $fname= $_GET['F_name'];
       $lname= $_GET['L_name'];
        $file= addslashes(file_get_contents($_FILES['image']['tmp_name']));
         $phone = $_GET['phone'];
          $address= $_GET['address'];

  $query="INSERT INTO `customer`(`F_name`, `L_name`, `phone`, `address`,`image`) VALUES ('$fname','$lname','$phone','$address','$image')";

       $data = mysqli_query($con,$query);

if($data){
   ?>
   <tr><td>
   <?php echo "Record updated successfully"; ?></td></tr>
    <?php
}
else{
   ?>
   <tr><td>
    <?php echo "Not updated";?></td></tr>
<?php
}
}
   else{
   ?>
   <tr><td>
      <?php echo "<font color='blue'>Click on Add Button to add new data!";?></td></tr>
      <?php 
   }
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	 <link rel="stylesheet" type="text/css" href="css1/edit_art.css">
</head>
<body>
<form action="customer2.php" method="GET" enctype="multipat/form-data">
<table>
<tr>
<td>First Name:</td>
<td><input type="text" name="F_name" value="" class="textInput" ></td></tr>
<tr>
   <tr>
<td>Last Name:</td>
<td><input type="text" name="L_name" value="" class="textInput"></td></tr>
<td>Image:</td>
<td><input type="file" name="image" value="" class="image"></td></tr>
<tr>
<td>Phone:</td><td><input type="text" name="phone" value="" class="textInput"></td></tr>
<tr>
<td>Address:</td><td><input type="text" name="address" value="" class="textInput"></td></tr>
	<td>
<h4 style="margin-left:20px"><input type="submit" name="submit" value="submit"></h4></td></tr>

<br>

</table>
</form>
</body>
</html>
<script>
     $(document).ready(function(){
      $("#insert").Click(function(){
       var image_name= $(#image).val();
        if(image_name==''){
         alert("Please Select Image");
          return false;
        }
        else{
         var extension=$('#image').val().split('.').pop().toLowerCase();
         if(jquery.inArray(extension,['gif','png','jpg','jpeg'])==-1){
            alert("Invalide Image File");
            $('#image').val('');
            return false ;
         }
        }

      })
     })


</script>




<?php
    $query =$con->prepare("SELECT * FROM `customer` WHERE  `user_id`='$user_id'");
       $query->execute();
       $res =$query->get_result();
       while($rest=$res->fetch_assoc()){ }
?>