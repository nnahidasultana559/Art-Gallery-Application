<?php
include("dbcon.php");

   ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	 <link rel="stylesheet" type="text/css" href="css/edit_art1.css">
</head>
<body>
<form action="customer3.php" method="GET" enctype="multipat/form-data">
<table>
<tr>
<td>First Name:</td>
<td><input type="text" name="F_name" value="" class="textInput" ></td></tr>
<tr>
   <tr>
<td>Last Name:</td>
<td><input type="text" name="L_name" value="" class="textInput"></td></tr>

<td>Phone:</td><td><input type="text" name="phone" value="" class="textInput"></td></tr>
<tr>
<td>Address:</td><td><input type="text" name="address" value="" class="textInput"></td></tr>
<td>Image:</td>
<td><input type="file" name="image" value="" class="image"></td></tr>
<tr>
	<td>
<h4 style="margin-left:20px"><input type="submit" name="submit" value="submit"></h4></td></tr>

<br>


<?php
include("dbcon.php");
if(isset($_GET['submit'])){
      $fname= $_GET['F_name'];
       $lname= $_GET['L_name'];
        $image=$_GET['image'];
         $phone = $_GET['phone'];
          $address= $_GET['address'];

  
  $query="INSERT INTO `customer`(`F_name`, `L_name`, `phone`, `address`,`image`) VALUES ('$fname','$lname','$phone','$address','$image') ";

       $data = mysqli_query($con,$query);

if($data){
   ?>
   <tr><td><td><?=$_GET['L_name']?></td>
   <?php echo "Record updated successfully" ?>; &nbsp;&nbsp;<a href="customer.php?add=<?=$_GET['L_name']?>">Check Added List Here</a></td></tr>
    <?php
}
else{
   ?>
   <tr><td>
    <?php echo "Not updated";?></td></tr>
<?php
}
}
   else{
   ?>
   <tr><td>
      <?php echo "<font color='blue'>Click on Add Button to add new data!";?></td></tr>
      <?php 
   }
?>
</table>
</form>
</body>
</html>

