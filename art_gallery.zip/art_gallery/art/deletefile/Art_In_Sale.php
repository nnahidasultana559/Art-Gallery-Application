<?php
session_start();
include('dbcon.php');
$status="";
if (isset($_POST['code']) && $_POST['code']!=""){
$code = $_POST['code'];
$result = mysqli_query($con,"SELECT  `Name`,`subject`, `code`, `images`, `price`, `style`, `medium`, `size`, `artist_country` FROM `art_in_sale` WHERE `code`=$code");
$row = mysqli_fetch_assoc($result);
$Name = $row['Name'];
$subject = $row['subject'];
$code = $row['code'];
$price = $row['price'];
$images = $row['images'];
$style  =$row['style'];
$medium  =$row['medium'];
$size  =$row['size'];
$artist_country  =$row['artist_country'];
$cartArray = array(
	$code =>array(
	'Name'=>$Name,
	'subject'=>$subject,
	'code'=>$code,
	'price'=>$price,
	'style'=>$style,
	'medium'=>$medium,
	'size'=>$size,
	'artist_country'=>$artist_country,
	'quantity'=>1,
	'images'=>$images)
);

if(empty($_SESSION["shopping_cart"])) {
	$_SESSION["shopping_cart"] = $cartArray;
	$status = "<div class='box'>Product is added to your cart!</div>";
}
else{
	$array_keys = array_keys($_SESSION["shopping_cart"]);
	if(in_array($code,$array_keys)) {
		$status = "<div class='box' style='color:red;'>
		Product is already added to your cart!</div>";	
	} 
	else {
	$_SESSION["shopping_cart"] = array_merge($_SESSION["shopping_cart"],$cartArray);
	$status = "<div class='box'>Product is added to your cart!</div>";
	}

	}
}
?>
<html>
<head>
<h3 class="active" align="left" style="color:white;margin-left: 20px;margin-top: 20px"><a href="index2.html">←Home Page</a></h3>
<title>Cart </title>
<link rel='stylesheet' href='css/artsale.css' type='text/css' media='all' />
</head>
<body>
<div style="width:1200px; margin:20 auto;">
<h1 align="center">ARTS </h1>   
<?php

if(!empty($_SESSION["shopping_cart"])) {
$cart_count = count(array_keys($_SESSION["shopping_cart"]));
?>
<div class="cart_div">
<a href="cart.php"><img src="cart-icon.png" /> Cart<span><?php echo $cart_count; ?></span></a>
</div>
<?php
}
?>
<?php
$result = mysqli_query($con,"SELECT `Name`,`subject`, `code`, `images`, `price`, `style`, `medium`, `size`, `artist_country` FROM `art_in_sale`");
while($row = mysqli_fetch_assoc($result)){
		echo "<div class='product_wrapper'>
			  <form method='post' action=''>
			  <input type='hidden' name='code' value=".$row['code']." />
			  <div class='images'><img src='".$row['images']."' /><br><br></div>
			  <div class='Name'>".$row['Name']."</div>
			  <div class='subject'>".$row['subject']."</div>
		   	  <div class='price'>$".$row['price']."</div>
		   	  <div class='medium'>".$row['medium']."</div>
		   	  <div class='style'>".$row['style']."</div>
		   	  <div class='size'>".$row['size']."</div>
		   	  <div class='artist_country'>".$row['artist_country']."</div>
			  <button type='submit' class='buy'>Buy Now</button>
			  <br><br><br>
			  </form>
		   	  </div>";
        }
mysqli_close($con);
?>
<div style="clear:both;"></div>
<br><br><br>
<div class="message box" style="margin:15px 0px;">
<?php echo $status; ?>
</div>
<br /><br />
</div>
</body>
</html>