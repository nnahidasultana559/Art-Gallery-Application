<?php 

include ("dbcon.php");
if (isset($_POST['register'])) {
  session_start();
$Username= $_POST['username'];
$email= $_POST['email'];
$password=$_POST['password'];
$password2=$_POST['password2'];

 if($password==$password2){
   $password=md5($password);
   $sql= "INSERT INTO admin (`name`, `password`, `email`) VALUES ('$Username','$password','$email')";
   mysqli_query($con,$sql);
   $_SESSION['message']="You are now logged in";
   $_SESSION['username']=$username;
   header('location:home.php');


 }
 else{
 $_SESSION['message']="The two passwords do not match";

 }
}

?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration</title>
  <style>
    body{
   padding: 0px;
   margin: 0px;
    }
    .header{
       background-color: #1A3333;
       color: white;
       text-align: center;
       top:0px;
       width: 100%;
       padding: 5px;
    }
    form{
     width: 40%;
     padding: 30px;
     border: 1px solid #cbcbcb;
     margin: 5px auto;
    }
    .textInput{
       margin-top: 2px;
       height: 28px;
       border: 1px solid #5E6E66;
       font-size: 16px;
       padding: 1px;
       width: 100%;
    }
    #error_msg{
      width: 50%;
      margin: 5px auto;
      height: 30px;
      border: 1px solid #FF0000;
      background: #FFB9B8;
      color: #FF0000;
      text-align: center;
      padding-top: 10px;


    }
    td{
      text-align: right;
    }
  </style>
</head>
<body>
<div class= "header">
  <h1>Registration</h1>
  
</div>
<form method="post" action="admin1.php">
  <table>
    <tr>
      <td>Username:</td>
      <td><input type="text" name="username" class="textInput"></td>
    </tr>
     <tr>
      <td>Email:</td>
      <td><input type="text" name="email" class="textInput"></td>
    </tr>
     <tr>
      <td>Password:</td>
      <td><input type="password" name="password" class="textInput"></td>
    </tr>
     <tr>
      <td>Confirm Password:</td>
      <td><input type="password" name="password2" class="textInput"></td>
    </tr>
      <tr>
      <td></td>
      <td><input type="submit" name="register" value="Register"></td>
    </tr>
  </table>
</form>
</body>
</html>