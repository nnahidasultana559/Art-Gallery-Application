<?php
include ("dbcon.php");

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
ul h2.active a{
  background-color:MediumSeaGreen;
  color:#00;
}
ul h2 a{
  text-decoration: none;
  color: white;
  padding: 10px 20px;
  border: 1px solid transition;
  transition: 0.4s ease;
}
ul h2 a:hover{
  background-color:green;
  color:#00;
}
</style>
</head>
<body>
<ul>
<h2 class="active" align="left" style= "color:white;margin-bottom: : 5px;"><a href="index2.html">Home page</a></h2></ul>
<br><h3 style="margin-left: 20px">Contact Form</h3>

<div class="container">
  <form action="buyticket.php"  method="GET">
    <div class="row">
          <div class="col-50">
            <h3>Billing Address</h3>
            <label for="fname"><i class="fa fa-user"></i> Full Name</label>
            <input type="text" id="name" name="name" placeholder="your name">
            <label for="email"><i class="fa fa-envelope"></i> Email</label>
            <input type="text" id="email" name="email" placeholder="XXX@example.com">
            <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
            <input type="text" id="adr" name="address" placeholder="your home address">
            <label for="qty"><i class="fa fa-address-card-o"></i> Quantity</label>
            <input type="text/number" id="qty" name="qty" placeholder="Ticket quantity less than 11">

          </div>

          <div class="col-50">
            <h3>Payment</h3>
            <label for="fname">Accepted Cards</label>
            <div class="icon-container">
              <i class="fa fa-cc-visa" style="color:navy;"></i>
              <i class="fa fa-cc-amex" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
            <label for="cname">Name on Card</label>
            <input type="text" id="cardname" name="cardname" placeholder="John More Doe">
            <label for="ccnum">Credit card number</label>
            <input type="text" id="cardnumber" name="cardnumber" placeholder="1111-2222-3333-4444">
            <label for="expmonth">Exp Month</label>
            <input type="text" id="expmonth" name="expmonth" placeholder="September">

            <div class="row">
              <div class="col-50">
                <label for="expyear">Exp Year</label>
                <input type="text" id="expyear" name="expyear" placeholder="2018">
              </div>
              <div class="col-50">
                <label for="cvv">CVV</label>
                <input type="text" id="cvv" name="cvv" placeholder="352">
              </div>
            </div>
          </div>

        </div>
        <label>
          <input type="checkbox" checked="checked" name="sameadr"> Shipping address same as billing
        </label>
        <input type="submit" name="submit" value="checkout" class="btn">

         <div class="col-25">
    <div class="container">
      <h4>Cart 
        <span class="price" style="color:black">
          <i class="fa fa-shopping-cart"></i> 
        </span>
      </h4>
      <p><a>Ticket price</a> <span class="price">$100.00</span></p>
         </div>
  </div>
  </form>
  <?php

if(isset($_GET['submit'])){
        $name=$_GET['name'];
        $address=$_GET['address'];
        $cardname=$_GET['cardname'];
        $cardnumber=$_GET['cardnumber'];
        $email=$_GET['email'];
        $expmonth=$_GET['expmonth'];
        $expyear=$_GET['expyear'];
        $cvv=$_GET['cvv'];
        $quantity=$_GET['qty'];
        $total_price=0; $price=100; 
  

  if($name!='' && $address!='' && $cardname!='' && $cardnumber!='' &&  $expyear!=''  && $expmonth!='' && $email!='' && $cvv!='' && $quantity!='' && $price!='' ){
     
    $query=("INSERT INTO `buytickets` (`name`, `address`, `email`, `cardname`, `cardnumber`, `expmonth`, `expyear`, `cvv`, `price`, `quantity`) VALUES ($name,$address,$email,$cardname,$cardnumber,$expmonth,$expyear,$cvv,$total_price,$quantity)");
      ;
  
      $data=mysqli_query($con,$query);

      if($data){
        echo "Ticket Purchased Successfully";
      }
      else {
        echo "not sent";
      }

      
}
  else{
    echo "All field are required";
  }
}

?>
</div>


</body>
</html>