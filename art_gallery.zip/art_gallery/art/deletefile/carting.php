
<?php 
session_start();
$product_codes=array();
//session_destroy();
if(filter_input(INPUT_POST,'add_to_cart')){
   if(isset($_SESSION['shopping_cart'])){
    //keep track how many products in the cart
    
    $count= count($_SESSION["shopping_cart"]);
    $product_codes =array_column($_SESSION['shopping_cart'],'code');

  if(!in_array(filter_input(INPUT_GET['shopping_cart'],'code'), $product_codes)){
    $_SESSION['shopping_cart'][$count]=array
     ( 
      'code' => filter_input(INPUT_GET,'code'),
       'Name' => filter_input(INPUT_POST,'Name'),
       'price' => filter_input(INPUT_POST,'price'),
       'quantity' => filter_input(INPUT_POST,'quantity')
     );
   }
     else{
       for( $i=0; $i<count($product_codes); $i++){
       if($product_codes[$i]==filter_input(INPUT_GET,'code')){
        // add iteam quantity to the existing product in the array
        $_SESSION['shopping_cart'][$i]['quantity'] += filter_input(INPUT_POST,'quantity');
       }
       }
     
  }
   }
   else{
     $_SESSION['shopping_cart'][0]=array
     ( 'code' => filter_input(INPUT_GET,'code'),
       'Name' => filter_input(INPUT_POST,'Name'),
       'price' => filter_input(INPUT_POST,'price'),
       'quantity' => filter_input(INPUT_POST,'quantity')
     );
   }
}

if(filter_input(INPUT_GET, 'action')=='delete'){
 foreach ($_SESSION['shopping_cart'] as $key => $product) {
   if($product['code'] == filter_input(INPUT_GET,'code')){
       unset($_SESSION['shopping_cart'][$key]);

    
   }
 }
  $_SESSION['shopping_cart']=array_values($_SESSION['shopping_cart'] );
}

   
//pre_r($_SESSION)
//*function pre_r($array){
   // echo '<pre>';
    //print_r($array);
    //echo "</pre>";
//}
?>

<!DOCTYPE html>
<html>
<head>
    <title></title>
     <link rel="stylesheet" type="text/css" href="css/style.css">
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1 shrink-to-fit=no">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link href="https://fonts.googleapis.com/css?family=Abril+Fatface|Dancing+Script" rel="stylesheet">   
</head>
<body class = "container ">
     <div class="btn-sm " >
     <br><a class="btn btn-info flex-fill" href="index2.html"role="button"> ← Home Page</a>
     </div>
    
    <h1 class="text-center text-primary mb-0" 
    style="font-family: 'Abril Fatface', cursive;">Art  iteams</h1>
    
    <div class="row " >
   
    <?php 

    include("dbcon.php");

    $query = "SELECT `Name`,`code`,`subject`,`style`, `medium`, `size`, `price`, `artist_country`, `images` FROM `art_in_sale` order by `code` ASC";
    
    $queryfire = mysqli_query($con,$query);

    $num = mysqli_num_rows($queryfire);
    
    if($num > 0){
        while($product = mysqli_fetch_array($queryfire)){
          
            ?>
           
        <div class="col-lg-3 col-md-3 col-sm-12"><br>
            
            <form method="post" action="carting.php?action=add&code=<?php echo $product['code'];?>">
                <div class="card">
                  
                    <h6 class="card-title bg-secondary text-white p-2 text-uppercase text-center"> <?php echo $product['Name'];  ?></h6>

                    <div class="card-body">
                         <img src="<?php echo
                         $product['images'];  ?>" class="img-fluid mb-2" alt="Cinque Terre"  alt="art"   >
                     
                     <h5 class="text-primary"> <?php echo '$'.$product['price']; ?></h5>
                     <h6 class="text-secondary"><span>Subject:<?php echo $product['subject']; ?></span> </h6>
                     <h6 class="text-secondary"><span>Size:<?php echo $product['size']; ?>  </span> </h6>
                     <h6 class="text-secondary">Style: <?php echo $product['style']; ?><span></h6>
                      <h6 class="text-secondary"> Medium:<?php echo $product['medium'];?> </span> </h6>
                     <h6 class="text-secondary">Artist Country: <?php echo $product['artist_country'];?> </h6> 

                     <h6 class="badge badge-info"> 4.4 <i class="fa fa-star"> </i> </h6>

                     <input type="text" name="quantity" class="form-control" value="1"/>
                     <input type="hidden" name="Name" value="<?php echo $product['Name'];?>"/>
                     <input type="hidden" name="price" value="<?php echo $product['price'];?>"/>

                    </div>
                    <div class="btn-group d-flex" >
                    <input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-info flex-fill" value="Add to Cart"/>
                    </div>
 
                <br>

                 
                </div>
            </form>
        </div>
        <?php
      }
       }
       ?>    
</div>
<div style="clear:both"></div>

        <div class='table-responsive'>
          <table class='table'>
          <tr><th colspan="5"><br><h3 align="center">Order Details</h3></th></tr>
          <tr>
            <th width="20%">Product Name</th>
            <th width="20%">Quantity</th>
            <th width="20%">Price</th>
            <th width="10%">Total</th>
            <th width="5%">Action</th>
          </tr>
          <?php 
          if(!empty($_SESSION['shopping_cart'])){
                 $total =0;
                 
        foreach($_SESSION['shopping_cart'] as $key =>$product){
             $name=$product['Name'];
             $price=$product['price'];
             $quantity=$product['quantity'];
             $code=$product['code'];
            ?>
            <tr>
              <td><?php echo $product['Name'];?></td>
              <td><?php echo $product['quantity'];?></td>
              <td>$<?php echo $product['price'];?></td>
              <td>$<?php echo number_format($product['quantity']*$product['price'],2);?></td>
              <td>
              <a href="carting.php?action=delete&code=<?php echo $product['code'];?>">
                <div class='btn-danger' align="center">Remove</div>
                
              </a>
            </td>
          </tr>
          <?php 
             $total =$total +($product['quantity']*$product['price']);

             $qry= "INSERT INTO `cart`(`product_name`, `product_price`, `product_quantity`, `product_img`, `total_price`, `code`) VALUES ('$name','$price','$quantity','','$total','$code')"; 
                
                $result = mysqli_query($con,$qry);
                print_r($result);
             
           }
           ?>
           <tr>
           <td colspan="3" align="right" style="color:white"><th width="15%">Total</th></td>
           <td align="right">$<?php echo number_format($total,2);?></td>
         </tr>
         <tr>
          <td colspan="5">
            <?php
            if(isset($_SESSION['shopping_cart'])){
              if(count($_SESSION['shopping_cart'])>0){

                ?>

                <a href="checkout.php" class='btn btn-info' action='button' >Checkout</a>

            <?php } } ?>
          </td>
        </tr>
        <?php
          
          }
        ?>
          </table>
          <br><br><br><br>
        </div>
        </body>
</html>
