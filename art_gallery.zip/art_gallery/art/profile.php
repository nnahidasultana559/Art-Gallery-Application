<?php 

include("dbcon.php");


?>

 <!DOCTYPE html>
<html>
<head>
  
 <meta charset="utf-8">
  <meta http-equiv="X-US-Compatible" content="IE-edge">
  <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
  <title>Arts</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
   <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

     
</head>
<body>
<h3 align="center">Profile</h3>
 <div class="row justify-content:space-around">
     
   
  <?php
   include ('dbcon.php');
   $lname= $_GET['add'];
   $query="SELECT * FROM  `customer`";
   $result=mysqli_query($con,$query);
    if ($row= $result->fetch_assoc()) {
    ?>
    <form method="GET" style="margin-left: 50px;margin-top: 40px;">
    <tr>
    <h4><img src="<?= $row['image']?>" width='200' align='center'></h4></tr>
    <tr><h4>First Name:<?=$row['F_name']?></h4></tr>
    

     <tr>
   
   <h4>Last Name<?=$row['L_name']?></h4></tr>
    <h4>Phone:<?=$row['phone']?></h4></tr>
     <h4>Address:<?=$row['address']?></h4></tr>
     
    

 <?php
    }

  ?>
  </form>
  </div>
</tr>
</thead>
