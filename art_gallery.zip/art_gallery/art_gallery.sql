-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 16, 2021 at 02:52 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `art_gallery`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(100) NOT NULL,
  `name` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `gallery_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `name`, `password`, `email`, `gallery_id`) VALUES
(8, 'tanu', '5b2d4484498235e80d61a233a7c04991', 'tani123@gmail.com', 1),
(27, 'nahida1', 'a002bb222e512d3697e6499c574459ac', 'nnahidasultana559@gmail.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `artist`
--

CREATE TABLE `artist` (
  `Artist_name` varchar(100) NOT NULL,
  `birth_place` varchar(200) NOT NULL,
  `art_work` varchar(1000) NOT NULL,
  `artist_id` int(100) NOT NULL,
  `type_of_art` varchar(1000) NOT NULL,
  `age` int(30) NOT NULL,
  `about` varchar(2000) NOT NULL,
  `education` varchar(1000) NOT NULL,
  `artist_image` varchar(1000) NOT NULL,
  `publication` varchar(1000) NOT NULL,
  `gallery_id` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `artist`
--

INSERT INTO `artist` (`Artist_name`, `birth_place`, `art_work`, `artist_id`, `type_of_art`, `age`, `about`, `education`, `artist_image`, `publication`, `gallery_id`) VALUES
('Irena Belcovski', 'Canada', 'Imaginary Dream, Acceptance, Embracing The World, Finding The Way', 12, 'Abstract, Modern, Canvas, Cubisium', 35, 'Irena Belcovski is an internationally recognized contemporary abstract painter. Her work has been exhibited by numerous independent Canadian galleries and is found in private collections the world over. Her pieces have several times been featured on Saatchi Art\'s homepage and in their 2014 \"Artist of the Day\" event. She further won third place in Saatchi Art\'s Showdown \"Back to Nature,\" an internationally recognized competition drawing thousands of entries. Born in Skopje, Macedonia, Irena has, since she was a child, held a fascination and true passion for art. She was introduced to painting by her grandfather who was a naive painter. Having received a B.A. from the Faculty of Law Studies at Ss. Cyril and Methodius University in Macedonia, Irena after enrolled in a 4-year mentorship in Prof. Milosh Milosavljevic\'s private atelier. In this, she cultivated her passion and began her life in fine arts. Irena boldly relocated in 2012 to Canada to pursue a full-time career in painting whilst also continuing her Fine Art studies at Sheridan College. Belcovski is currently a successful artist living and working in the Greater Toronto Area. She has been an elected member of the Society of Canadian Artists since 2015. She has also been featured on the cover and centerfold of Professional Artist Magazine and interviewed for \"Artist Spotlight\" in Dec./Jan. 2014\'s issue. Less', '- (2014-2016) Fine Arts, Sheridan College,Faculty of Continuing and Professional studies, Oakville,ON, Canada\r\n- (2013) Icon Painting workshop, Sacred Murals Studio\r\n- (2008-2011) Studio Art, Atelier \'Likovna Rabotilnica\' Skopje, Macedonia\r\n- (1998-2003) B.A, Ss. Cyril and Methodius University of Skopje\r\n', 'artist1.jpg', '-2014 Dec/Jan. Professional Artist Magazine.', 1),
('Birgit Huttemann-Holz', 'Detroit, MI, United States', 'Cathedral, My Dining Room Table, Revolution-1', 14, 'Abstract, Modern, Real life', 54, 'Birgit\'s energetic works show a lush world, where nature is in constant celebration. Orchids, verdant gardens, and imaginary spaces become synonym with sanctuaries. Deeply inspired by the beauty of flowers and landscapes, Huttemann-Holz pushes her subject to a place of gestural abstraction with sweeping gestures, layering curves, and punctuating forms of saturated tones. She employs a myriad of media, including encaustic, oil, acrylic, encaustic monotype and even throwing and painting ceramics. Birgit Huttemann-Holz depicts both her vision and feeling of a world where beauty and vulnerability are the touching keystones. She has exhibited nationally and internationally and is represented in Germany, The Netherlands, and in the US. She was awarded Finalist of the International Portrait Competition, Society for Art of Imagination, UK (2011), Best of Show, Platform Award, OK (2013), Best of Show, NANA 14, FL (2014) and won multiple awards nationwide. Her work was selected for Studio Visit Magazine, winter edition 2013, spring edition 2017, for the Palm Award, Germany (Certificate of Excellence), 2015, Saatchi Collections \"New This Week\", April 2014, January 2018,\" Inspired by Cy Twombly\" April 2018, \" Inspired by Jackson Pollock\" Jan 2019, The Other Art Fair, Brooklyn, NY, Nov 2017 and May 2018, and The Other Art Fair Chicago, IL, September 2018. In February 2017, she attended a month-long residency at The Studios of Key West. Her book \"Enkaustik- Das Grundlagenbuch zur Wachsmalerei\" was published April 2015 by Christopherus Verlag, Germany and translated into English in 2017, \"How to create Encaustic Art- A guide to painting with wax\". \"Wachsmalerei- Birgit Huttemann-Holz\", a tutorial video and three documentations were published in 2016/2017 with the group \"geistreich-lernen.de\", Germany Birgit Is showing her new work @The Other Art Fair Brooklyn, NY and Chicago, IL in May 2019. Huttemann-Holz lives and works in Detroit, USA.', '2014 8th International Encaustic Conference, Provincetown, MA\r\n2004-2013 Continued Education in Fine Art:\r\n2013/2014 Advanced Monoprint, Paula Roland, Santa Fe \r\n2010 Summer Academy for the Arts, Marburg Germany, Prof Andras Ernszt, Hungary\r\n2009 IEA Retreat, panelist Tony Scherman\r\n2004-2007 Continued Education, CCS College for Creative Studies, Detroit\r\n1991-94 Studies in German Literature, Media Science, Philosophy at University of Karlsruhe and Philipps University Marburg, Germany\r\n1989 B.A. Physical Therapy, Ludwigshafen/ Schoemberg, Germany', 'artist2.jpg', '', 1),
('Evan Shevaski', 'France', 'Real life,Modern people', 22, 'Sketch,Canvas,Abstract', 56, 'Evan Shevaski is an internationally recognized contemporary abstract painter. His work has been exhibited by numerous independent French galleries and is found in private collections the world over. ', 'Sacred Murals Studio(2008-2011) Studio Art, Atelier', 'artist3.jpg', 'In 2013, a art work named real life people by Evan Shevaski published! which become him famous. His work in human known as best.', 1);

-- --------------------------------------------------------

--
-- Table structure for table `art_in_sale`
--

CREATE TABLE `art_in_sale` (
  `Name` varchar(200) NOT NULL,
  `subject` varchar(1000) NOT NULL,
  `style` varchar(1000) NOT NULL,
  `medium` varchar(1000) NOT NULL,
  `artist_name` varchar(500) NOT NULL,
  `artist_country` varchar(100) NOT NULL,
  `size` varchar(500) NOT NULL,
  `price` int(20) NOT NULL,
  `images` varchar(1000) NOT NULL,
  `code` int(100) NOT NULL,
  `gallery_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `art_in_sale`
--

INSERT INTO `art_in_sale` (`Name`, `subject`, `style`, `medium`, `artist_name`, `artist_country`, `size`, `price`, `images`, `code`, `gallery_id`) VALUES
('Imaginary Dream 1', 'Abstract', 'Abstract,Modern,  Canvas', 'Acrylic', 'Irena Belcovski', 'Australia', '56W x 36H x 1.5in', 2200, 'acrylic.jpg', 1, 1),
('Revolution-1', 'Modern Art', 'Abstract', 'Acrylic,Pgmentstick', 'Birgit Huttemann-Holz', 'United States', '36W x 36H x 1in', 1300, 'modern1.jpg', 2, 1),
('where time does not exist II', 'Nature Beauty', 'Fine Art,Modern, Surrealism,Realism', 'Acrylic,Oil, Spray Paint', 'Johanna Bath', 'Germany', '47.2W x 55.1H x 0.8 in', 920, 'modern2.jpg', 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `buytickets`
--

CREATE TABLE `buytickets` (
  `ticket_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `address` varchar(500) NOT NULL,
  `email` varchar(200) NOT NULL,
  `cardname` varchar(200) NOT NULL,
  `cardnumber` varchar(200) NOT NULL,
  `expmonth` varchar(100) NOT NULL,
  `expyear` varchar(100) NOT NULL,
  `cvv` varchar(100) NOT NULL,
  `price` int(20) NOT NULL,
  `quantity` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buytickets`
--

INSERT INTO `buytickets` (`ticket_id`, `name`, `address`, `email`, `cardname`, `cardnumber`, `expmonth`, `expyear`, `cvv`, `price`, `quantity`) VALUES
(2, 'nahida', '34hjbd', 'nnahidasultana559@gmail.com', 'tgsh sfjk', '111-3-44', 'oct', '2021', '233', 300, 3),
(4, 'tanu', '34hjbd', 'tani123@gmail.com', 'tgsh sfjk', '124141', 'oct', '2021', '1244', 300, 4);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `product_name` varchar(200) NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_quantity` int(30) NOT NULL,
  `product_img` varchar(1000) NOT NULL,
  `total_price` int(100) NOT NULL,
  `code` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`product_name`, `product_price`, `product_quantity`, `product_img`, `total_price`, `code`) VALUES
('Imaginary Dream 1', 2200, 2, 'acrylic.jpg', 4400, 1),
('Revolution-1', 1300, 1, 'modern1.jpg', 1300, 2);

-- --------------------------------------------------------

--
-- Table structure for table `checkout`
--

CREATE TABLE `checkout` (
  `id` int(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` int(15) NOT NULL,
  `address` varchar(200) NOT NULL,
  `pmode` varchar(500) NOT NULL,
  `products` varchar(20000) NOT NULL,
  `amount_paid` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `checkout`
--

INSERT INTO `checkout` (`id`, `name`, `email`, `phone`, `address`, `pmode`, `products`, `amount_paid`) VALUES
(1, 'tanzina', 'suprova01@yahoo.com', 1716315442, '7/4/3-ka dhaka', 'cards', 'Imaginary Dream(1)', 2200),
(2, 'nahi', 'nahida@gmail.com', 1716315442, '7/4-ka', 'cards', 'where time doesn', 5360),
(3, 'tanzina', 'tan@gmail.com', 1716315442, '7/4/3-ka dhalpur', 'cod', 'Imaginary Dream(2),where time doesn', 6240),
(4, 'nahu', 'nishu@gmail.com', 1716315442, '7/4 hjgh', 'netbanking', 'Imaginary Dream(2),where time doesn', 6240),
(10, 'nahida', 'nnahidasultana559@gmail.com', 1716315442, '57/shantibagh', 'netbanking', 'Imaginary Dream(2),where time doesn', 7540),
(11, 'tanu', 'tanzaniaera@yahoo.com', 1716315442, '878 ighj', 'netbanking', 'Imaginary Dream(2),where time doesn', 7540),
(32, 'samaya', 'samaya@gmail', 3131483, '327 fdsg', 'net banking', 'where time does not exist, Imaginary dream, Revultaion fyguh', 222000),
(33, 'nahu', 'nahu@gmail.com', 1716315442, '45678 rtyui', 'cod', 'Imaginary Dream(2),where time doesn', 7540),
(34, 'fgihj', 'samayasara2@gmail.com', 456789, '345678fghjk', 'cod', 'Imaginary Dream(2),where time doesn', 7540),
(36, 'chgjvjh', 'samayasara2@gmail.com', 34567, '3456 edgfhg', 'cod', 'Imaginary Dream(2),where time doesn', 6620),
(37, 'tanu', 'suprova01@yahoo.com', 1716315442, '2345 sdfghn', 'cod', 'Revolution-1(1),where time doesn', 4420),
(38, 'chgjvjh', 'suprova01@yahoo.com', 34567890, '345 drtfgyh', 'cod', 'Revolution-1(1),where time doesn', 4060),
(39, 'tanu', 'tan@gmail.com', 1716315442, '7/4/3-ka dhalpur', 'netbanking', 'Imaginary Dream 1(2),Revolution-1(1)', 5700);

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `c_id` int(20) NOT NULL,
  `First_name` varchar(200) NOT NULL,
  `Last_name` varchar(200) NOT NULL,
  `email_address` varchar(500) NOT NULL,
  `msg` varchar(1000) NOT NULL,
  `gallery_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`c_id`, `First_name`, `Last_name`, `email_address`, `msg`, `gallery_id`) VALUES
(1, 'nahida', 'sultana', 'nnahidasultana559@gmail.com', 'tshdkjg', 1),
(3, 'tanzian', 'akter', 'tan@gmail.com', 'what is?', 1);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cus_id` int(20) NOT NULL,
  `F_name` varchar(200) NOT NULL,
  `L_name` varchar(200) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(200) NOT NULL,
  `discount` varchar(100) NOT NULL DEFAULT '$100',
  `image` varchar(100) NOT NULL,
  `username` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exhibition`
--

CREATE TABLE `exhibition` (
  `exhibition_id` int(20) NOT NULL,
  `title` varchar(500) NOT NULL,
  `theme` varchar(1000) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `start_time` varchar(20) NOT NULL,
  `end_time` varchar(20) NOT NULL,
  `E_artist_details` varchar(2000) NOT NULL,
  `place` varchar(200) NOT NULL,
  `ticket_price` int(12) NOT NULL,
  `gallery_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exhibition`
--

INSERT INTO `exhibition` (`exhibition_id`, `title`, `theme`, `start_date`, `end_date`, `start_time`, `end_time`, `E_artist_details`, `place`, `ticket_price`, `gallery_id`) VALUES
(1, 'Gaze', 'Canvas, Figure, Cubisum', '2019-08-28', '2019-08-31', '3 p.m', '9 p.m', 'Irfan Onurmen\'s first solo exhibition \"Gaze\"\r\nIrfan Onurmen\'s Gaze Series\' large sized portraits give way to psychological and political readings, relate to the anonymous yet  familiar  characters and feelings to reference to our external and internal worlds. The artist\'s layered and slightly blurry tulles, geometrically cut forms, joyful brightness and cheerful outlook urges the viewer to think deeper.', 'UK, 4 Mandeville Place, W1U 2BG.London', 220, 1),
(3, 'Imaginary World', 'Visulization', '2019-08-30', '2019-09-03', '3 p.m', '9 p.m', '', 'Wilington,Newzland', 400, 1);

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `gallery_id` int(20) NOT NULL,
  `gallery_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`gallery_id`, `gallery_name`) VALUES
(1, 'art gallery');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(20) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `discount` varchar(20) NOT NULL DEFAULT '$100',
  `username` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `email`, `password`, `discount`, `username`) VALUES
(18, 'nnahidasultana559@gmail.com', '202cb962ac59075b964b07152d234b70', '$100', 'nahida1'),
(21, 'tan@gmail.com', '202cb962ac59075b964b07152d234b70', '$100', 'tas'),
(24, 'samayasara2@gmail.com', '092e376ae9c6ace3be1397ae14e5633c', '$100', 'tani');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD KEY `gallery_id` (`gallery_id`);

--
-- Indexes for table `artist`
--
ALTER TABLE `artist`
  ADD PRIMARY KEY (`artist_id`),
  ADD KEY `gallery_id` (`gallery_id`);

--
-- Indexes for table `art_in_sale`
--
ALTER TABLE `art_in_sale`
  ADD PRIMARY KEY (`code`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `gallery_id` (`gallery_id`);

--
-- Indexes for table `buytickets`
--
ALTER TABLE `buytickets`
  ADD PRIMARY KEY (`ticket_id`),
  ADD UNIQUE KEY `ticket_id` (`ticket_id`),
  ADD KEY `ticket_id_2` (`ticket_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`code`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `checkout`
--
ALTER TABLE `checkout`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`c_id`),
  ADD KEY `gallery_id` (`gallery_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cus_id`),
  ADD KEY `username` (`username`),
  ADD KEY `discount` (`discount`);

--
-- Indexes for table `exhibition`
--
ALTER TABLE `exhibition`
  ADD PRIMARY KEY (`exhibition_id`),
  ADD KEY `gallery_id` (`gallery_id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`gallery_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `email_2` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `artist`
--
ALTER TABLE `artist`
  MODIFY `artist_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `art_in_sale`
--
ALTER TABLE `art_in_sale`
  MODIFY `code` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `buytickets`
--
ALTER TABLE `buytickets`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `checkout`
--
ALTER TABLE `checkout`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `c_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `cus_id` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exhibition`
--
ALTER TABLE `exhibition`
  MODIFY `exhibition_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `gallery_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin`
--
ALTER TABLE `admin`
  ADD CONSTRAINT `fk_admin` FOREIGN KEY (`gallery_id`) REFERENCES `gallery` (`gallery_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `artist`
--
ALTER TABLE `artist`
  ADD CONSTRAINT `fk_artist` FOREIGN KEY (`gallery_id`) REFERENCES `gallery` (`gallery_id`);

--
-- Constraints for table `art_in_sale`
--
ALTER TABLE `art_in_sale`
  ADD CONSTRAINT `fk_art` FOREIGN KEY (`gallery_id`) REFERENCES `gallery` (`gallery_id`);

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `fk_cart` FOREIGN KEY (`code`) REFERENCES `art_in_sale` (`code`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD CONSTRAINT `fk_con` FOREIGN KEY (`gallery_id`) REFERENCES `gallery` (`gallery_id`);

--
-- Constraints for table `exhibition`
--
ALTER TABLE `exhibition`
  ADD CONSTRAINT `fk_ex` FOREIGN KEY (`gallery_id`) REFERENCES `gallery` (`gallery_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
